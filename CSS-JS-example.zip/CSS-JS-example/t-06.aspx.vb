﻿
Partial Class n_1_1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub enter_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles enter.Click
        message.Text = username.Text & "您好，欢迎您光临我的主页"
    End Sub
End Class
