﻿
Partial Class T_1_1
    Inherits System.Web.UI.Page

    Protected Sub Enter_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles enter.Click
        Message.Text = username.Text & "您好，欢迎您光临我的主页"
    End Sub

End Class
