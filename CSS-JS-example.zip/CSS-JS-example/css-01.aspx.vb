﻿
Partial Class css_02
    Inherits System.Web.UI.Page

End Class
