﻿
Partial Class t1_2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Label1.Text = TextBox1.Text & "您好！"
    End Sub
End Class
