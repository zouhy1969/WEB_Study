﻿
Partial Class n_1_2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = " 您输入的姓名是：" & Request.Form("username") & "，密码是：" & Request.Form("userpass")
    End Sub
End Class
